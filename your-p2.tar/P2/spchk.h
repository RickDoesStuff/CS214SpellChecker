#ifndef SPCHK_H
#define SPCHK_H
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "spchk.h"
#include "linestream.h"
#include "binaryTree.h"
#include "filestream.h"

int wordDictCompare(struct BinaryTreeNode *tree, struct BinaryTreeNode *treeCaps, char* path);

#endif